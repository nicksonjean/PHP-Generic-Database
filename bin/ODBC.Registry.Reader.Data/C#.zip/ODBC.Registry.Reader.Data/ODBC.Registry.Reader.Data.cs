﻿using System;
using System.IO;
using System.Linq;

class ODBC_Registry_Reader_Data
{
    const string DEFAULT_ARCHITECTURE = "x64";
    const string DEFAULT_ROOT_KEY = "HKLM";
    const string DEFAULT_REGISTRY_PATH = "SOFTWARE\\ODBC\\ODBCINST.INI";
    const string DEFAULT_OUTPUT_TYPE = "memory";
    const string DEFAULT_OUTPUT_FILE = "odbc_settings.json";
    const bool DEFAULT_DRIVERS_AVAILABLE = false;

    public static void ProcessCommandLineArgs(ref OdbcRegistryReader.RegistryArgs args)
    {
        string[] commandLineArgs = Environment.GetCommandLineArgs();
        for (int i = 1; i < commandLineArgs.Length; i++)
        {
            string arg = commandLineArgs[i];
            if (arg.StartsWith("--architecture="))
            {
                args.Architecture = arg.Substring("--architecture=".Length);
            }
            else if (arg.StartsWith("--rootKey="))
            {
                args.RootKey = arg.Substring("--rootKey=".Length);
            }
            else if (arg.StartsWith("--registryPath="))
            {
                args.RegistryPath = arg.Substring("--registryPath=".Length);
            }
            else if (arg.StartsWith("--outputType="))
            {
                args.OutputType = arg.Substring("--outputType=".Length);
            }
            else if (arg.StartsWith("--outputFile="))
            {
                args.OutputFile = arg.Substring("--outputFile=".Length);
            }
            else if (arg.Equals("-j"))
            {
                args.DriversAvailable = true;
            }
            else
            {
                throw new Exception("Invalid Argument: " + arg);
            }
        }
    }

    static void Main(string[]_)
    {
        try
        {
            OdbcRegistryReader.RegistryArgs Args = new()
            {
                Architecture = DEFAULT_ARCHITECTURE,
                RootKey = DEFAULT_ROOT_KEY,
                RegistryPath = DEFAULT_REGISTRY_PATH,
                OutputType = DEFAULT_OUTPUT_TYPE,
                OutputFile = DEFAULT_OUTPUT_FILE,
                DriversAvailable = DEFAULT_DRIVERS_AVAILABLE
            };

            ProcessCommandLineArgs(ref Args);

            OdbcRegistryReader.RegistryReader RegistryReader = new(Args);
            try
            {
                RegistryReader.ReadRegistry();
            }
            finally
            {
                
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"{e.GetType().Name}: {e.Message}");
        }
    }
}
