﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace OdbcRegistryReader
{
    public class RegistryArgs
    {
        public string Architecture { get; set; }
        public string RootKey { get; set; }
        public string RegistryPath { get; set; }
        public string OutputType { get; set; }
        public string OutputFile { get; set; }
        public bool DriversAvailable { get; set; }
    }

    public class RegistryReader
    {
        private readonly RegistryArgs _args;
        private readonly List<string> _exceptKeys;

        public RegistryReader(RegistryArgs args)
        {
            _args = args;
            _exceptKeys = new List<string> { "ODBC Core", "ODBC Drivers", "ODBC Translators", "Administrator", "ODBC" };
        }

        private static string RemoveInvalidCharacters(string input)
        {
            Dictionary<string, string> patterns = new()
            {
                { @"[^ -~]*", string.Empty },
                { @"(\.dll|\.DLL|Installed|YYY|NNN|YNN|NYY|YNY|NYN|NNY|YYN|\d{2}\.\d{2}).*", "$1" }
            };

            foreach (var pattern in patterns)
            {
                Regex regex = new Regex(pattern.Key);
                input = regex.Replace(input, pattern.Value);
            }

            return input;
        }
#pragma warning disable CA1416
        private static RegistryHive SetRegistryKey(string rootKey)
        {
            return rootKey switch
            {

                "HKLM" => RegistryHive.LocalMachine,
                "HKCU" => RegistryHive.CurrentUser,
                "HKCR" => RegistryHive.ClassesRoot,
                "HKCC" => RegistryHive.CurrentConfig,
                "HKU" => RegistryHive.Users,
                _ => throw new ArgumentException("Invalid Root Key"),
            };
        }

        private List<string> ReadKeysAvailable(string registryKey)
        {
            var result = new List<string>();
            using (var registry = Registry.LocalMachine.OpenSubKey(registryKey, false))
            {
                if (registry != null)
                {
                    var subKeys = registry.GetSubKeyNames();
                    foreach (var subKey in subKeys)
                    {
                        if (!_exceptKeys.Contains(subKey))
                        {
                            result.Add(subKey);
                        }
                    }
                }
            }
            return result;
        }

        private Dictionary<string, object> ReadKeysSettings(string registryKey)
        {
            using var registry = RegistryKey.OpenBaseKey(SetRegistryKey(_args.RootKey), (_args.Architecture == "x86") ? RegistryView.Registry32 : RegistryView.Registry64);
            var result = new Dictionary<string, object>();
            var subKeys = registry.OpenSubKey(registryKey)?.GetSubKeyNames() ?? new string[0];

            foreach (var subKey in subKeys)
            {
                if (!_exceptKeys.Contains(subKey))
                {
                    result.Add(subKey, ReadKeysSettingsData(Path.Combine(registryKey, subKey)));
                }
            }

            return result;
        }

        private Dictionary<string, object> ReadKeysSettingsData(string registryPath)
        {
            using var registry = RegistryKey.OpenBaseKey(SetRegistryKey(_args.RootKey), (_args.Architecture == "x86") ? RegistryView.Registry32 : RegistryView.Registry64);
            using var subKey = registry.OpenSubKey(registryPath);
            var result = new Dictionary<string, object>();
            if (subKey != null)
            {
                foreach (var valueName in subKey.GetValueNames())
                {
                    if (!_exceptKeys.Contains(valueName))
                    {
                        var registryValue = subKey.GetValue(valueName);
                        if (registryValue != null)
                        {
                            switch (subKey.GetValueKind(valueName))
                            {
                                case RegistryValueKind.String:
                                case RegistryValueKind.ExpandString:
                                    string cleanedString = RemoveInvalidCharacters(registryValue.ToString());
                                    result.Add(valueName, cleanedString.Replace("\0", "").Trim('\0'));
                                    break;
                                case RegistryValueKind.DWord:
                                    result.Add(valueName, (int)registryValue);
                                    break;
                                case RegistryValueKind.Binary:
                                    var bytes = (byte[])registryValue;
                                    var hexString = BitConverter.ToString(bytes).Replace("-", "");
                                    result.Add(valueName, hexString);
                                    break;
                                default:
                                    result.Add(valueName, "Unsupported Data Type");
                                    break;
                            }
                        }
                    }
                }
            }

            return result;
        }
#pragma warning restore CA1416
        public void ReadRegistry()
        {
            if (_args.DriversAvailable)
            {
                var jsonArray = ReadKeysAvailable(_args.RegistryPath);
                try
                {
                    if (_args.OutputType.Equals("file", StringComparison.OrdinalIgnoreCase))
                    {
                        File.WriteAllText(_args.OutputFile, JsonConvert.SerializeObject(jsonArray, Formatting.None));
                    }
                    else
                    {
                        Console.WriteLine(JsonConvert.SerializeObject(jsonArray, Formatting.None));
                    }
                }
                finally
                {
                    jsonArray.Clear();
                }
            }
            else
            {
                var jsonObject = ReadKeysSettings(_args.RegistryPath);
                try
                {
                    if (_args.OutputType.Equals("file", StringComparison.OrdinalIgnoreCase))
                    {
                        File.WriteAllText(_args.OutputFile, JsonConvert.SerializeObject(jsonObject, Formatting.None));
                    }
                    else
                    {
                        Console.WriteLine(JsonConvert.SerializeObject(jsonObject, Formatting.None));
                    }
                }
                finally
                {
                    jsonObject.Clear();
                }
            }
        }
    }
}
